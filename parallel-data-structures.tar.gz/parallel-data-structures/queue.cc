#include "queue.hh"

#include <stdlib.h>

// Initialize a new queue
void queue_init(my_queue_t* queue) {
  
}

// Destroy a queue
void queue_destroy(my_queue_t* queue) {
  
}

// Put an element at the end of a queue
void queue_put(my_queue_t* queue, int element) {
  
}

// Check if a queue is empty
bool queue_empty(my_queue_t* queue) {
  return true;
}

// Take an element off the front of a queue
int queue_take(my_queue_t* queue) {
  return -1;
}
