# CSC 213 &ndash; Concurrent Data Structures Lab


Please complete your written responses to parts B and C below.

## Part B

### Invariants
*Please write your invariants for your queue data structure here.*

> Response goes here

## Part C
*Briefly describe your implementation and synchronization strategy for the dictionary datatype here.*

> Response goes here

### Concurrent Accesses
*Describe which accesses to this data structure may proceed in parallel, and which accesses will block one another.*

> Response goes here

### Invariants
*Write your invariants for the dictionary data structure here.*

> Response goes here
