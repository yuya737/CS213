#include "dict.hh"

#include <stdlib.h>

// Initialize a dictionary
void dict_init(my_dict_t* dict) {
  
}

// Destroy a dictionary
void dict_destroy(my_dict_t* dict) {
  
}

// Set a value in a dictionary
void dict_set(my_dict_t* dict, const char* key, int value) {
  
}

// Check if a dictionary contains a key
bool dict_contains(my_dict_t* dict, const char* key) {
  return false;
}

// Get a value in a dictionary
int dict_get(my_dict_t* dict, const char* key) {
  return -1;
}

// Remove a value from a dictionary
void dict_remove(my_dict_t* dict, const char* key) {
  
}
