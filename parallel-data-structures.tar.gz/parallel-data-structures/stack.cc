#include "stack.hh"

#include <stdlib.h>

// Initialize a stack
void stack_init(my_stack_t* stack) {
  
}

// Destroy a stack
void stack_destroy(my_stack_t* stack) {
  
}

// Push an element onto a stack
void stack_push(my_stack_t* stack, int element) {
  
}

// Check if a stack is empty
bool stack_empty(my_stack_t* stack) {
  return true;
}

// Pop an element off of a stack
int stack_pop(my_stack_t* stack) {
  return -1;
}
